#define BUILD_BRANCH ""
#define BUILD_COMMIT ""
#define BUILD_DATE ""
#define BUILD_TIME ""
