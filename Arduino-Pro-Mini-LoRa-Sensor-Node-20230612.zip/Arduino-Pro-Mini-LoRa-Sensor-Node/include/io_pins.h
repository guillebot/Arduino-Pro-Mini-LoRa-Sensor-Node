#define PIN_DHT 3
#define PIN_INFO_LED 9

// PIN definition for module
#define PIN_LMIC_NSS  10
#define PIN_LMIC_RST  9
#define PIN_LMIC_DIO0 2
#define PIN_LMIC_DIO1 5
