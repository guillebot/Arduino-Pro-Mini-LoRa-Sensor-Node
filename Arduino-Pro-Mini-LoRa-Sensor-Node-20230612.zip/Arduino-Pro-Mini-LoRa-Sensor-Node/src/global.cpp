#include "global.h"
#include "io_pins.h"

float HUMIDITY = NAN;
float TEMPERATURE = NAN;
int VALUEA0 = 0;
DHT DHTSENSOR;
